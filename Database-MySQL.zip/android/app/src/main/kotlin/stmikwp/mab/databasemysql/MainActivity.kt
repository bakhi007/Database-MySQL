package stmikwp.mab.databasemysql

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
